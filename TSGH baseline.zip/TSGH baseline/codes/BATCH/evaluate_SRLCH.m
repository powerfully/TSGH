function evaluation_info=evaluate_SRLCH(I_tr,T_tr,L_tr,I_te,T_te,LTest,param)
    
    anchor = 500;
    Ntrain = size(I_tr, 1); % Train samples
    Ntest = size(I_te, 1); % Test samples
    I_te = bsxfun(@minus, I_te, mean(I_tr, 1));
    I_tr = bsxfun(@minus, I_tr, mean(I_tr, 1));
    T_te = bsxfun(@minus, T_te, mean(T_tr, 1));
    T_tr = bsxfun(@minus, T_tr, mean(T_tr, 1));
    
    I_tr = normalize(I_tr);
    I_te = normalize(I_te);
    T_tr = normalize(T_tr);
    T_te = normalize(T_te);
    
    [I_tr, I_te, T_tr, T_te] = Phi_kernel_all(I_tr, I_te, T_tr, T_te, Ntrain, Ntest, anchor);
    show_loss = 0;
    nbits = param.nbits;
    tic;
    [H, PV, PT,~] = trainSRCH(I_tr, T_tr, L_tr, param, nbits, Ntrain, show_loss);
    
    % Img2Txt
    tHI = I_te*PV;

    % Txt2Img
    tHT = T_te*PT;
    
    % Hash codes generation
    H = H > 0;
    tHI = tHI > 0;
    tHT = tHT > 0;
    
    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    BxTest = compactbit(tHI);
    BxTrain = compactbit(H);
    DHamm = hammingDist(BxTest, BxTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', L_tr, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', L_tr, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', L_tr, LTest,param.top_K);
    
    ByTest = compactbit(tHT);
    ByTrain = compactbit(H); % ByTrain = BxTrain;
    DHamm = hammingDist(ByTest, ByTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', L_tr, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', L_tr, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', L_tr, LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
