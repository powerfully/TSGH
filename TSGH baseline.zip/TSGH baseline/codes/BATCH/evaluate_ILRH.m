function evaluation_info=evaluate_ILRH(XKTrain,YKTrain,LTrain,XKTest,YKTest,LTest,param)
      
    tic;
    
    % Hash codes learning
    [B] = nus_algorithm(XKTrain,YKTrain,LTrain,param);
    % Hash functions learning
    XW = B * XKTrain' * pinv(XKTrain * XKTrain' + 10 * eye(size(XKTrain,1)));
    YW = B * YKTrain' * pinv(YKTrain * YKTrain' + 10 * eye(size(YKTrain,1)));
                            
   

    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    tUX = XW * XKTest;
    tVY = YW * YKTest;
    BxTest = compactbit(sign(tUX') >= 0);
    BxTrain = compactbit(sign(B')>0);
    DHamm = hammingDist(BxTest, BxTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    
    ByTest = compactbit(sign(tVY') >= 0);
    ByTrain = compactbit(sign(B')>0);
    DHamm = hammingDist(ByTest, ByTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
