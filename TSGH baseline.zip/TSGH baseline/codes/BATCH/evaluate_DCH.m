function evaluation_info=evaluate_DCH(XKTrain,YKTrain,LTrain,XKTest,YKTest,LTest,param)
    
    tic
    [tHX,tHT,H] =DCH_train(XKTrain', YKTrain', XKTest', YKTest', LTrain, LTest,param);
              
    
    
    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    tBX = compactbit(sign(tHX) >= 0);
    B = compactbit(sign(H) >= 0);
    DHamm = hammingDist(tBX, B);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    
    tBT = compactbit(sign(tHT) >= 0);
    B = compactbit(sign(H) >= 0);
    DHamm = hammingDist(tBT, B);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
