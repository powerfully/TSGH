function evaluation_info=evaluate_SMFH(I_tr,T_tr,L_tr,I_te,T_te,LTest,param)
    
    tic;
    k_nn = param.k_nn;
      %% mixed graph regularization term
    W_img = adjacency(I_tr, 'nn', k_nn); % model the intra-modal similarity in image modality
    W_txt = adjacency(T_tr, 'nn', k_nn); % model the intra-modal similarity in text modality
    W_inter = L_tr * L_tr'; % model the label cosistency between the image and text modality
    

    [row, col] = size(I_tr);
    D_img = zeros(row, row);
    D_txt = zeros(row, row);
    D_inter = zeros(row, row);

    W_img(W_img ~= 0) = 1;
    W_txt(W_txt ~= 0) = 1;

    for i = 1:row
        D_img(i, i) = sum(W_img(i, :));
        D_txt(i, i) = sum(W_txt(i, :));
        D_inter(i, i) = sum(W_inter(i, :));
    end

    L_i = D_img - W_img;
    clear D_img W_img;

    L_t = D_txt - W_txt;
    clear D_txt W_txt;

    L_inter = D_inter - W_inter;
    clear D_inter W_inter;

    L = L_i + L_t + L_inter;
    clear L_i L_t L_inter;

    I_temp = I_tr';
    T_temp = T_tr';

    I_temp = bsxfun(@minus, I_temp, mean(I_temp, 2));
    T_temp = bsxfun(@minus, T_temp, mean(T_temp, 2));

    Im_te = (bsxfun(@minus, I_te', mean(I_tr', 2)))';
    Te_te = (bsxfun(@minus, T_te', mean(T_tr', 2)))';

    Im_db = (bsxfun(@minus, I_tr', mean(I_tr', 2)))';
    Te_db = (bsxfun(@minus, T_tr', mean(T_tr', 2)))';

    clear I_tr T_tr I_te T_te I_db T_db;
    %% solve the objective function

    [P1, P2, S] = solveSMFH(I_temp, T_temp, L, param.alpha, param.beta, param.gamma, param.lambda, param.nbits);
     
    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    

    % Cross-Modal Retrieval
    
    Yi_te = sign((bsxfun(@minus, P1 * Im_te', mean(S, 2)))');
    Yi_db = sign((bsxfun(@minus, P1 * Im_db', mean(S, 2)))');

    Yt_te = sign((bsxfun(@minus, P2 * Te_te', mean(S, 2)))');
    Yt_db = sign((bsxfun(@minus, P2 * Te_db', mean(S, 2)))');

    %add by zhangzhen
    Yi_te = Yi_te > 0;
    Yi_db = Yi_db > 0;
    Yt_te = Yt_te > 0;
    Yt_db = Yt_db > 0;
    
    BxTest = compactbit(Yi_te>0);
    BxTrain = compactbit(Yt_db>0);
    DHamm = hammingDist(BxTest, BxTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', L_tr, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', L_tr, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', L_tr, LTest,param.top_K);
    
    ByTest = compactbit(Yt_te> 0);
    ByTrain = compactbit(Yi_db>0); % ByTrain = BxTrain;
    DHamm = hammingDist(ByTest, ByTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', L_tr, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', L_tr, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', L_tr, LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
