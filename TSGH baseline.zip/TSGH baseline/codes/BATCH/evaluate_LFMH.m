function evaluation_info=evaluate_LFMH(XKTrain,YKTrain,LTrain,XKTest,YKTest,LTest,param)
    
    tic
    [U1, U2, W1, W2, Z1, Z2 ] = solveLFMH(XKTrain, YKTrain, LTrain, param);

    V1 = Z1 * LTrain;
    V2 = Z2 * LTrain;

    HX1_tr = sign((bsxfun(@minus, V1, mean(V1,2)))');  
    HX1_te = sign((bsxfun(@minus, W1 * XKTest', mean(V1,2)))');
    HX2_tr = sign((bsxfun(@minus, V2, mean(V2,2)))');   
    HX2_te = sign((bsxfun(@minus, W2 * YKTest', mean(V2,2)))'); 
                  
    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    B_HX1_te = bitCompact(HX1_te >= 0);
    B_HX2_tr = bitCompact(HX2_tr >= 0);
    DHamm = hammingDist(B_HX1_te, B_HX2_tr);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', LTrain', LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', LTrain', LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', LTrain', LTest,param.top_K);
    
    B_HX1_tr = bitCompact(HX1_tr >= 0);
    B_HX2_te = bitCompact(HX2_te >= 0);
    DHamm = hammingDist(B_HX2_te, B_HX1_tr);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', LTrain', LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', LTrain', LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', LTrain', LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
