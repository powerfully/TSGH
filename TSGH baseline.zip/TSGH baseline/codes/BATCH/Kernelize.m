function [KTrain, KTest] = Kernelize(Train,Test,db_name)
    [n,~]=size(Train);
    [nT,~]=size(Test);
    if strcmp(db_name, 'wiki_data')
        n_anchor= 500; 
    elseif strcmp(db_name, 'mirflickr25k')
        n_anchor= 1000; 
    elseif strcmp(db_name, 'nusData')
        n_anchor= 1000; 
    elseif strcmp(db_name, 'IAPRTC-12')
        n_anchor= 1000; 
    end
    n_anchor= 500;   
    
    anchor=Train(randsample(n,n_anchor),:);
   
    KTrain = sqdist222(Train',anchor');
    sigma = mean(mean(KTrain,2));
    KTrain = exp(-KTrain/(2*sigma));  
    mvec = mean(KTrain);
    KTrain = KTrain-repmat(mvec,n,1);
    
    KTest = sqdist222(Test',anchor');
    KTest = exp(-KTest/(2*sigma));
    KTest = KTest-repmat(mvec,nT,1);
end