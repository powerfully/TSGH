function [HUte2,HVte2,U,V] = MTFH(I_tr,T_tr,L_tr,I_te,T_te,L_te,param)
S = L_tr * L_tr';
%MTFH Summary of this function goes here
%   Detailed explanation goes here
    bits = param.nbits;
    alpha = param.alpha;
    beta = param.beta;
    anchorNum = param.anchorNum;
    n1 = size(I_tr, 1);     
    n2 = size(T_tr, 1);     
    n_te = size(I_te, 1);  
for q1 = bits       %
    for q2 = bits   
        %% initialization
        U = sign(normrnd(0, 1, n1, q1));
        U_ = sign(normrnd(0, 1, n2, q1));
        V_ = sign(normrnd(0, 1, n1, q2));
        V = sign(normrnd(0, 1, n2, q2));
        H1 = rand(q1, q2);
        H2 = rand(q1, q2);

        %% firt stage
        [U, V, U_, V_, H1, H2] = rndsolveUHV2(alpha, beta, q1, q2, S, U, U_, V, V_, H1, H2);

        %% second stage
        % rnd
        anchorIndex = sort(randperm(n1, anchorNum));
        anchor1 = I_tr(anchorIndex, :);
        anchor2 = T_tr(anchorIndex, :);
        
        % count ¦Ò^2
        z = I_tr * I_tr';
        z = repmat(diag(z), 1, n1)  + repmat(diag(z)', n1, 1) - 2 * z;
        sigma1 = mean(z(:));

        z = T_tr * T_tr';
        z = repmat(diag(z), 1, n1)  + repmat(diag(z)', n1, 1) - 2 * z;
        sigma2 = mean(z(:));

        % kernel logstic regression
        Kanchor1 = kernelMatrix(anchor1, anchor1, sigma1);
        Kanchor2 = kernelMatrix(anchor2, anchor2, sigma2);
        Ktr1 = kernelMatrix(I_tr, anchor1, sigma1);
        Ktr2 = kernelMatrix(T_tr, anchor2, sigma2);
        Kte1 = kernelMatrix(I_te, anchor1, sigma1);
        Kte2 = kernelMatrix(T_te, anchor2, sigma2);

        HUte1 = zeros(n_te, q1);
        HVte1 = zeros(n_te, q2);

        % parameters of KLR
        options = {};
        options.Display = 'final';
        C = 0.01;
    
        % learn KLR for modality Iamge
        for b = 1: q1
            h = U(:, b);
            funObj = @(u)LogisticLoss(u, Ktr1, h);
            w = minFunc(@penalizedKernelL2, zeros(size(Kanchor1, 1),1), options, Kanchor1, funObj, C);
            HUte1(:, b) = sign(Kte1 * w);
        end

        % learn KLR for modality Text
        for b = 1: q2
            h = V(:, b);
            funObj = @(u)LogisticLoss(u, Ktr2, h);
            w = minFunc(@penalizedKernelL2, zeros(size(Kanchor2, 1),1), options, Kanchor2, funObj, C);
            HVte1(:, b) = sign(Kte2 * w);
        end

        % transformation for cross modal retrieval
        HVte2 = sign(HUte1 * H2);
        HUte2 = sign(HVte1 * H1');

    
        
    end
end
end

