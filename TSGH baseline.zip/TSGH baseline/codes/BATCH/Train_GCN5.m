function [U1, U2, V1, V2, W1, W2, B, QX, QY] = Train_GCN5(X, T, Z, C )
%min ||X-U1V1||^2 + ||Y-U2V2||^2 
%+ alpha*||V1-W1XDAD||^2 + alpha*||V2-W2YDAD||^2 
%+ beta*||V1-V2||^2 
%+ ceta*||B'V1-rS||^2 +  ceta*||B'V2-rS||^2
% stage 2
% min ||B-QX||^2 + xi*||QXSX'Q'||^2
maxItr=10;
alpha = C.lambda1;
beta = C.lambda2;
ceta = C.lambda3;
gama  = 0;
xi  = C.lambda4;
% gama1 = 0;
 [S,~] = LabelDist(Z);
% Sv = S;
% St = S;
% L  = D;
% Dv = D;
% Dt = D;
[~,n1] = size(X); 
% A = S; % + eye(n1);
D = zeros(n1,n1);
for i = 1:n1
    sum = 0;
    for j = 1:n1
        sum = sum + S(i, j);
    end
    D(i,i) = sum;
end

%% ��ʼ��
r = C.bits;
[d1,n1] = size(X); 
[d2,n2] = size(T);
% Q = rand(d1,n);
% A = rand(d2,n);
U1 = rand(d1,r);
U2 = rand(d2,r);
V1 = rand(r, n1);
V2 = rand(r, n2);
W1 = rand(r, d1);
W2 = rand(r, d2);
% U = rand(n,n1);
% V = rand(n,n1);
% G = D^-1/2 * S * D^-1/2;
G = zeros(n1,n1);
if G==G'
    flag=1;
else
    flag=0;
end
B = rand(r,n1);
% E1 = zeros(n,n1) ;
% E2 = zeros(n,n1) ; 
% muta = 0.1 ;
% lambda = 0.99;
% muta_max = 1e10;
Y = T;
tol = 0.00001;

%% ������⿪ʼ
     i=0; 
for t=1:maxItr    
%     if t==1
%         f_prev = 1e10000;
%     else
%         f_prev = f(t-1);
%     end
     i=i+1; 
    
%     Q_old = Q;
%     A_old = A;
%     U_old = U;
%     V_old = V;
%     P1_old = P1;
%     P2_old = P2;

%% U-step ���U1,U2
    U1 = (X*V1')* pinv(V1*V1');
    U2 = (Y*V2')* pinv(V2*V2');


%% W-step ���W1,W2
%      W1 = 1/(1+ceta+beta) * (Q1'*X*G'*X' + ceta*W2*T*G*G'*X' + beta*B*G'*X') * pinv(X*G*G'*X'); 
%      W2 = 1/(alpha+ceta+beta) * (alpha*Q2'*T*G'*T' + ceta*W1*X*G*G'*T' + beta*B*G'*T') * pinv(Y*G*G'*T');
    W1 = (V1*G'*X')* pinv(X*G*G'*X');
    W2 = (V2*G'*Y')* pinv(Y*G*G'*Y');
    
%% V-step ���V1,V2
    V1 = pinv(U1'*U1+(alpha+beta + gama)*eye(r)+ceta*B*B') * (U1'*X + alpha*W1*X*G + beta*V2 + ceta*r*B*S + gama*B);
    V2 = pinv(U2'*U2 + (alpha+beta+ gama)*eye(r) + ceta*B*B') * (U2'*Y +alpha*W2*Y*G + beta*V1 + ceta*r*B*S + gama*B);
%  %% P-step ���P1,P2 
%      [U1,~,V1] = svd(X*G'*X'*W1','econ');
%      Q1=U1*V1';
%      [U2,~,V2] = svd(T*G'*T'*W2','econ');
%      Q2=U2*V2'  ;   
%% B-step
%     B = sign( pinv(V1*V1' + V2*V2') * (r*V1*S + r*V2*S));
    B = pinv(V1*V1' + V2*V2') * (r*V1*S + r*V2*S);
% %% U-step ���U,V
%      U = (2*P1'*X*Sv+muta*(Q'*X+C1/muta)+2*alpha*V*L+(2*beta-1/2)*V+B)/(2*(Dv+alpha*L)+(2*beta+1/2+muta)*eye(n1));
%      V = (2*ceta*P2'*T*St+muta*(A'*T+C2/muta)+2*alpha*U*L+(2*beta-1/2)*U+B)/(2*(ceta*Dt+alpha*L)+(2*beta+1/2+muta)*eye(n1));
%     B=(U+V)/2; 
% K=round(X'*Q,3);
% O=round(T'*A,3);
     
% %% parameter-step ���C1,C2,muta
%      C1 = C1+muta*(Q'*X-U);
%      C2 = C2+muta*(A'*T-V);
%      
%     LL1 = norm(A-A_old,'fro');
%     LL2 = norm(U-U_old,'fro');
%     LL3 = norm(V-V_old,'fro');
%     LL4 = norm(Q-Q_old,'fro');
%     LL5 = norm(P1-P1_old,'fro');
%     LL6 = norm(P2-P2_old,'fro');
%     SLSL = max(max(max(max(max(LL1,LL2),LL3),LL4),LL5),LL6);
%     
%     if SLSL*muta/norm(X,'fro') < 0.01
%         muta = min(lambda*muta,muta_max);
%     end
     

     
%% ���ƫ��
       norm1 = norm(X - U1*V1 , 'fro') ^ 2 + norm(Y - U2*V2 , 'fro') ^ 2;
       norm2 = norm(V1 - W1*X*G , 'fro') ^ 2 + norm(V2 - W2*Y*G , 'fro') ^ 2 ;
       norm3 = norm(V1 - V2 , 'fro') ^ 2;
       norm4 = norm(B'*V1 - r*S , 'fro') ^ 2 + norm(B'*V2 - r*S , 'fro') ^ 2; 
       norm5 = norm(B -V1 , 'fro') ^ 2 + norm(B -V2 , 'fro') ^ 2;
        f(t)=  norm1 + alpha*norm2 + beta*norm3 + ceta*norm4 +gama*norm5;
        fprintf('The iteration is : %i and f val is : %f \n', t, f(t));
%            
%        a(t)=round(norm(X-P1*Q'*X,2),2);
%        b(t)=round(norm(Q'*X-A'*T,2),2);
% end
% E=corr(X);
% F=corr(T);
% E1=corr(X'*Q);
% F1=corr(A'*T);
% [pc1,latent,percentage_each_vectorX]=pcacov(E);
% [pc1,latent1,percentage_each_vectorY]=pcacov(F);
% [pc1,latent1,percentage_each_vectorX1]=pcacov(E1);
% [pc2,latent2,percentage_each_vectorY2]=pcacov(F1);
%          l=norm((X-P1*Q'*X) , 2)/norm(X, 2);
%          l1=norm((T-P2*A'*T) , 2)/norm(T, 2);
%  save('PCA1.mat','percentage_each_vectorX','percentage_each_vectorY','percentage_each_vectorX1','percentage_each_vectorY2','l','l1')
end
% % just for ablation
% B = sign((V1+V2)/2);

C1= NormalizeFea(Z',1);
On = ones(1,n1);
S1 = 2*C1'*C1- On'*On;
[k1,~] = size(X); 
[k2,~] = size(Y); 
QX = (2*B*X' + xi*B*S1*X') * pinv(2*X*X' + 2*0.01*eye(k1));
QY = (2*B*Y' + xi*B*S1*Y') * pinv(2*Y*Y'+ 2*0.01*eye(k2));
end

