function evaluation_info=evaluate_GCN(XKTrain,YKTrain,LTrain,XKTest,YKTest,LTest,param)
    
    GTrain = NormalizeFea(LTrain,1);
    
    tic;
    
    % Hash codes learning
%     B = train_BATCH(GTrain,XKTrain,YKTrain,LTrain,param);
%     [U1, U2, V1, V2, W1, W2, B] = Train_GCN(XKTrain', YKTrain', LTrain, param );
%     [U1, U2,  W1, W2, B] = Train_GCN2(XKTrain', YKTrain', LTrain, param );
%     [V1, V2, W1, W2, B, Gx, Gy] = Train_GCN3(XKTrain', YKTrain', LTrain, param );
%     [ V1, V2, W1, W2, B, Q] = Train_GCN_Hij(XKTrain', YKTrain', LTrain, param );
%       [U1, U2, V1, V2, W1, W2, B, QX, QY] = Train_GCN4(XKTrain', YKTrain', LTrain, param );
      [U1, U2, V1, V2, W1, W2, B, QX, QY] = Train_GCN5(XKTrain', YKTrain', LTrain, param );
    
    B = B';
    % Hash functions learning
%     XW = (XKTrain'*XKTrain+param.xi*eye(size(XKTrain,2)))    \    (XKTrain'*B);
%     YW = (YKTrain'*YKTrain+param.xi*eye(size(YKTrain,2)))    \    (YKTrain'*B);

    
    XW = QX';
    YW = QY';

    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    BxTest = compactbit(XKTest*XW>0);
    BxTrain = compactbit(B>0);
    DHamm = hammingDist(BxTest, BxTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    
    ByTest = compactbit(YKTest*YW> 0);
    ByTrain = compactbit(B>0); % ByTrain = BxTrain;
    DHamm = hammingDist(ByTest, ByTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
%     compressiontime=toc;
    
%     evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
