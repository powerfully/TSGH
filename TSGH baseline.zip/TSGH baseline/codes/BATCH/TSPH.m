function [W1, W2, P1, P2,B1,B2] = TSPH(trainLabel, param, XKTrain,YKTrain,XKTest,YKTest,LTest)

X1 = XKTrain;
X2 = YKTrain;
XTest = XKTest;
YTest = YKTest;
testL = LTest;
databaseL = trainLabel;

[~,d1] = size(X1);
[d,d2] = size(X2);
bit1 = param.nbits;
bit2 = bit1;
maxIter = param.maxIter;
rou = param.rou;
sampleColumn = param.num_samples;

lambda = param.lambda;
gamma = param.gamma;
eta = param.eta;
alpha = param.alpha;

numTrain = size(trainLabel, 1);

B1 = ones(numTrain, bit1);
B1(randn(numTrain, bit1) < 0) = -1;
% V = V_opt';
c = size(trainLabel,2);
B2 = ones(numTrain, bit2);
B2(randn(numTrain, bit2) < 0) = -1;
V1 = randn(numTrain, bit1);
V2 = randn(numTrain, bit2);
V1(randn(numTrain, bit1) < 0) = -1;
V2(randn(numTrain, bit2) < 0) = -1;
P1 = randn(bit1, bit2);
P2 = randn(bit2, bit1);
G1 = randn(bit1,c);
G2 = randn(bit2,c);
L = trainLabel'; 
L_T =databaseL';
    for i = 1:size(L_T,2)
        D_temp(:,i) = L_T(:,i)/norm(L_T(:,i),2);
    end
D = D_temp';
for epoch = 1:maxIter
   %% for test instance
   %% sample Sc
    Sc = randperm(numTrain, sampleColumn);
    % update B1
    SX = trainLabel * trainLabel(Sc, :)' > 0;
    SY = trainLabel(Sc, :) * trainLabel' > 0;
    V2 = updateColumnV(V2, B2, SX, Sc, bit2, lambda, sampleColumn, P1, B1, eta);

    % update B2
    V1 = updateColumnV(V1, B1, SX, Sc, bit1, lambda, sampleColumn, P2, B2, eta);
    
    [B2,loss2] = updateColumnB(B2, V1, V2, SY, Sc, bit2, lambda, sampleColumn, P2, eta,alpha,databaseL,G2);
    [B1,loss1] = updateColumnB(B1, V2, V1, SY, Sc, bit1, lambda, sampleColumn, P1, eta,alpha,databaseL,G1);

    % update P

    P1 =  (eta * B1' * B1 + gamma * eye(bit1)) \ (eta * B1' * V2);
    P2 =  (eta * B2' * B2 + gamma * eye(bit2)) \ (eta * B2' * V1);

    % update G1
    G1 = (alpha * B1' * B1 + gamma * eye(bit1)) \ (alpha *B1' * databaseL);

    % update G2
    G2 = (alpha * B2' * B2 + gamma * eye(bit2)) \ (alpha *B2' * databaseL);

   %evaluation
 
    %loss function
    norm1 = loss2;
    norm2 = loss1;
    norm3 = eta * (norm(V1 - B2 * P2, 'fro') + norm(V2 - B1 * P1, 'fro'));
    norm4 = alpha * (norm(databaseL - B1 * G1, 'fro') + norm(databaseL - B2 * G2, 'fro'));
    norm5 = gamma * (norm(G1, 'fro') + norm(G2, 'fro') + norm(P1, 'fro') + norm(P2, 'fro'));
    currentF= norm1 +  norm2 + norm3 + norm4 + norm5;
    fprintf('\nobj at iteration %d: %.4f\n reconstruction error1: %.4f,\n reconstruction error2: %.4f,\n reconstruction error3: %.4f,\n reconstruction error4: %.4f,\n econstruction error5: %.4f,\n', epoch, currentF, norm1, norm2, norm3,norm4,norm5);
end
    W1 = (X1' * X1 + 0.01 * eye(d1)) \ (rou * X1' * B1 + bit2 * X1' * D * D' * B2 * P1') / (rou * eye(bit1) + P1 * (B2' * B2) * P1');
    W2 = (X2' * X2 + 0.01 * eye(d2)) \ (rou * X2' * B2 + bit1 * X2' * D * D' * B1 * P2') / (rou * eye(bit2) + P2 * (B1' * B1) * P2');
%     W1 = (X1' * X1 + rou * eye(d1)) \ (X1' * B1);
%     W2 = (X2' * X2 + rou * eye(d2)) \ (X2' * B2);
%%
% B1_t = B1';
% B_raw_t = normalize(B1_t);        % 数据标准化
% B_raw = B_raw_t';						   % 由于tsne标准输入数据以行向量表示，因此先转置
% Y3 = tsne(B_raw);                  % 得到的矩阵为Nx2，N为N个样本，Y矩阵为320x2
% v3 = gscatter(Y3(:,1), Y3(:,2),trainLabel,'','^');% 若无label输入，则画出的图没有色彩区分
% 
% B2_t = B2';
% B2_raw_t = normalize(B2_t);        % 数据标准化
% B2_raw = B2_raw_t';						   % 由于tsne标准输入数据以行向量表示，因此先转置
% Y4 = tsne(B2_raw);                  % 得到的矩阵为Nx2，N为N个样本，Y矩阵为320x2
% v4 = gscatter(Y4(:,1), Y4(:,2),trainLabel,'','v');% 若无label输入，则画出的图没有色彩区分

% T = [B1_t  B2_t];% 320个样本数据，以1024维列向量表示，组成1024x320数据矩阵X
% T = normalize(T);        % 数据标准化
% T = T';						   % 由于tsne标准输入数据以行向量表示，因此先转置 
% trainLabel2 = trainLabel + ones(size(trainLabel,1),size(trainLabel,2));
% trainLabel3 = [trainLabel;trainLabel];
% Y5 = tsne(T); 
% gscatter(Y5(:,1), Y5(:,2),trainLabel3,'','^');% 若无label输入，则画出的图没有色彩区分
end

%V2, B2, SX, Sc, bit2, lambda, sampleColumn, P1, eta
function U = updateColumnV(U, B, S, Sc, bit, lambda, sampleColumn, P,B1, eta)
m = sampleColumn;
n = size(U, 1);
for k = 1: bit
    TX = lambda * U * B(Sc, :)'/ bit;
    AX = 1 ./ (1 + exp(-TX));
    Bjk = B(Sc, k)';
    p1 = lambda * ((S - AX) .* repmat(Bjk, n, 1)) * ones(m, 1) / bit;
    p2 = (m * lambda^2 + 8 *bit^2 * eta)* U(:, k) / (4 * bit^2);
    temp = U - B1 * P;
    p3 = 2 * eta * temp(:,k);
    p = p1 + p2 - p3 ;
    U_opt = ones(n, 1);
    U_opt(p < 0) = -1;
    U(:, k) = U_opt;
end
end

%B2 ,V2, SY, Sc, bit2, lambda, sampleColumn, P2, B2, et
function [B,loss] = updateColumnB(B,U_ano, U, S, Sc, bit, lambda, sampleColumn, P,eta,alpha,L,G)
m = sampleColumn;
n = size(U, 1);
for k = 1: bit
    TX = lambda * U(Sc,:) * B' / bit;
    AX = 1 ./ (1 + exp(-TX));
    Ujk = U(Sc, k)';
    temp1 = U_ano * P';
    temp2 = B * P * P';
    temp3 = L * G' - B * G * G';
    p1 = lambda * ((S' - AX') .* repmat(Ujk, n, 1)) * ones(m, 1) / bit;
    p2 = (m * lambda^2 + 8 *bit^2*eta + 8 *bit^2*alpha)* B(:, k) / (4 * bit^2);
    p3 = -2*eta*( temp1(:,k)- temp2(:,k)) -2* alpha*temp3(:,k);
    p = p1 + p2 - p3;
    B_opt = ones(n, 1);
    B_opt(p < 0) = -1;
    B(:, k) = B_opt;
end
    theta = lambda * U(Sc, :) * B' / bit;
    l = log(1 + exp(theta)) - S .* theta;
    loss = sum(sum(l));
end

