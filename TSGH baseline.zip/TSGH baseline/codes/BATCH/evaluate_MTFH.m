function evaluation_info=evaluate_MTFH(I_tr,T_tr,L_tr,I_te,T_te,L_te,param)
      
    tic;
    [HUte2,HVte2,U,V] = MTFH(I_tr,T_tr,L_tr,I_te,T_te,L_te,param);
    


    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
   
    
    %% Cross-Modal Retrieval

        BxTest = compactbit(HVte2 >= 0);
        BxTrain = compactbit(V>=0);
        DHamm = hammingDist(BxTest, BxTrain);
        [~, orderH] = sort(DHamm, 2);
        evaluation_info.Image_VS_Text_MAP = mAP(orderH', L_tr, L_te);
        [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', L_tr, L_te);
        evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', L_tr, L_te,param.top_K);

        ByTest = compactbit(HUte2 >= 0);
        ByTrain = compactbit(U>=0);
        DHamm = hammingDist(ByTest, ByTrain);
        [~, orderH] = sort(DHamm, 2);
        evaluation_info.Text_VS_Image_MAP = mAP(orderH', L_tr, L_te);
        [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', L_tr, L_te);
        evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', L_tr, L_te,param.top_K);

    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
