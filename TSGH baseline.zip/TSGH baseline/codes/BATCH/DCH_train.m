%%
%% function SDH_train use the SDL method for two modalities in the same framework
%  for X and T, we use different anchor
function [tHX,tHT,H] = DCH_train...
    (train_abstract_X_opt, train_abstract_T_opt, test_abstract_X_opt, test_abstract_T_opt, Ltraining, Ltest, param)

tic;

traindata_X = double(train_abstract_X_opt');
traindata_T = double(train_abstract_T_opt');
testdata_X = double(test_abstract_X_opt');
testdata_T = double(test_abstract_T_opt');

traingnd = double(Ltraining);
testgnd  = double(Ltest);

% Use all the training data
Ntrain = size(traindata_X,1);

X = traindata_X;
T = traindata_T;
label = double(traingnd);
n_anchors = param.anchors;
% get anchors
% n_anchors = Ntrain;
% n_anchors = 1000;
% rand('seed',1);

if n_anchors == 0
    n_anchors = Ntrain;
end
%��ͼ������ÿһ���������һ�£��õ�anchor
anchor = X(randsample(Ntrain, n_anchors),:);
anchor2 = T(randsample(Ntrain, n_anchors),:);


PhiX = X;
PhiT = T;
Phi_testdata_X = testdata_X;
Phi_testdata_T = testdata_T;
Phi_traindata_X = traindata_X;
Phi_traindata_T = traindata_T;
%% �����趨
sigma = param.sigma; 
maxItr = param.maxItr;
gmap.lambda = param.gmap.lambda; 
gmap.loss = param.gmap.loss;
Fmap.type = param.Fmap.type;
Fmap.nu = param.Fmap.nu; %  penalty parm for F term
Fmap.mu = param.Fmap.mu;
Fmap.lambda = param.Fmap.lambda;
nbits =param.nbits;
% learn G and F

%% run algo
%��ʼ��һ��2173*16�Ķ�����Z
Zinit=sign(randn(Ntrain,nbits));
%ȷ���Բ���ʾloss
debug = 1;
[G, F, H] = DCH_discrete(PhiX,PhiT, label,Zinit,gmap,Fmap,[],maxItr,debug);
%% evaluation
% display(sprintf('Evaluation with %d bits, %d achors for rfb... \n', nbits, n_anchors));

AsymDist = 0; % Use asymmetric hashing or not

if AsymDist 
    H = H > 0; % directly use the learned bits for training data
else
    HX = Phi_traindata_X*F.W;
    HT = Phi_traindata_T*F.Wt;
    
    H = H;
end

tHX = Phi_testdata_X*F.W;
tHT = Phi_testdata_T*F.Wt;


%% use another evaluation metrics


traintime=toc;

end
