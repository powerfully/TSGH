function evaluation_info=evaluate_CMFH(XKTrain,YKTrain,LTrain,XKTest,YKTest,LTest,param)
    

    tic;
    
    % Hash codes learning
%     B = train_BATCH(GTrain,XKTrain,YKTrain,LTrain,param);
    [V,P1,P2] = solveCMFH(XKTrain, YKTrain, LTrain', param);
    Yi_tr = sign((bsxfun(@minus, V, mean(V,1))));
    Yt_tr = sign((bsxfun(@minus, V, mean(V,1))));
    Yi_tr(Yi_tr<0) = 0;
    Yt_tr(Yt_tr<0) = 0;


    Yi_te = sign((bsxfun(@minus, XKTest*P1', mean(XKTest*P1',1))));
    Yt_te = sign((bsxfun(@minus, YKTest*P2', mean(YKTest*P2',1))));
    Yi_te(Yi_te<0) = 0;
    Yt_te(Yt_te<0) = 0;
    
    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    BxTest = compactbit(Yi_te);
    BxTrain = compactbit(Yt_tr');
    DHamm = hammingDist(BxTest, BxTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    
    ByTest = compactbit(Yt_te);
    ByTrain = compactbit(Yi_tr'); % ByTrain = BxTrain;
    DHamm = hammingDist(ByTest, ByTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
