function evaluation_info=evaluate_SePH(XKTrain,YKTrain,LTrain,XKTest,YKTest,LTest,param)
      
    tic;
    
    % Hash codes learning
    [W1, W2, P1, P2,B1,B2] = TSPH(LTrain,param, XKTrain,YKTrain,XKTest,YKTest,LTest);
    % Hash functions learning

    traintime=toc;
    evaluation_info.trainT=traintime;
    
    tic;
    
    % Cross-Modal Retrieval
    BxTest = compactbit((XKTest*W1)*P1 > 0);
    BxTrain = compactbit(B2>0);
    DHamm = hammingDist(BxTest, BxTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Image_VS_Text_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Image_VS_Text_precision, evaluation_info.Image_VS_Text_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Image_To_Text_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    
    ByTest = compactbit((YKTest*W2)*P2 > 0);
    ByTrain = compactbit(B1>0);
    DHamm = hammingDist(ByTest, ByTrain);
    [~, orderH] = sort(DHamm, 2);
    evaluation_info.Text_VS_Image_MAP = mAP(orderH', LTrain, LTest);
    [evaluation_info.Text_VS_Image_precision,evaluation_info.Text_VS_Image_recall] = precision_recall(orderH', LTrain, LTest);
    evaluation_info.Text_To_Image_Precision = precision_at_k(orderH', LTrain, LTest,param.top_K);
    compressiontime=toc;
    
    evaluation_info.compressT=compressiontime;
    %evaluation_info.BxTrain = BxTrain;
    %evaluation_info.ByTrain = ByTrain;
    %evaluation_info.B = B;

end
