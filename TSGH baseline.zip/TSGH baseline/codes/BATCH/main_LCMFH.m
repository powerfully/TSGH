function [Yi_tr,Yi_te,Yt_te] = main_LCMFH(I_tr, T_tr, I_te, T_te, L, param)
% Reference:
% Di Wang, Xinbo Gao, Xiumei Wang, and Lihuo He. 
% Label Consistent Matrix Factorization Hashing. 
% IEEE Transactions on Pattern Analysis and Machine Intelligence, 41(10):2466 - 2479, 2019.
% (Manuscript)
%
% Contant: Di Wang (wangdi@xidain.edu.cn)
%
% Parameter Setting

lambda = param.lambda;
mu = param.mu;
gamma = param.gamma;
maxIter = param.maxIter;
bits = param.nbits;


if isvector(L) 
    L = sparse(1:length(L), double(L), 1); L = full(L);
end
L = normalizeFea(L);

[P1, P2, Z] = solveLCMFH(I_tr, T_tr, L, lambda, mu, gamma, bits, maxIter);
Yi_tr = sign((bsxfun(@minus, L*Z, mean(L*Z,1))));
Yt_tr = sign((bsxfun(@minus, L*Z, mean(L*Z,1))));
Yi_tr(Yi_tr<0) = 0;
Yt_tr(Yt_tr<0) = 0;


Yi_te = sign((bsxfun(@minus, I_te*P1, mean(I_te*P1,1))));
Yt_te = sign((bsxfun(@minus, T_te*P2, mean(T_te*P2,1))));
Yi_te(Yi_te<0) = 0;
Yt_te(Yt_te<0) = 0;
