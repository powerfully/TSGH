db = 'coco_cnn'; 
load(['./datasets/',db,'.mat']);
save(['./datasets/',db,'_split.mat'], 'I_te', 'I_tr','L_te','L_tr','T_te','T_tr')